<?php
return [
    'welcome' => 'স্বাগতম :name',
    'dashboard' => 'ডাসবোর্ড',
];
