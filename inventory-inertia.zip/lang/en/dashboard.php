<?php
return [
    'welcome' => 'Welcome :name',
    'dashboard' => 'Dashboard',
];
