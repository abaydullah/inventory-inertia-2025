<script setup>
import {computed, reactive, ref, watch} from "vue";
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import {Head, Link, router, useForm} from '@inertiajs/vue3';
import {
    TransitionRoot,
    TransitionChild,
    Dialog,
    DialogPanel,
    DialogTitle, Switch,
} from '@headlessui/vue'
import {debounce, throttle} from "lodash";
import Pagination from "@/Components/Pagination.vue";
import Header from "@/Layouts/Header.vue";
import 'vue-select/dist/vue-select.css';
import VSelect from "vue-select";
import InputSwitch from "@/Components/InputSwitch.vue";

import {QuillEditor} from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css';

const props = defineProps({
    notices: Object,
    instructors: Object,
    filters: {
        search: String,
        fee_type: Object,
        notice_type: Object,
        type: Object,
        start_date: '',
        end_date: '',

    },
    errors: Object,
})
let fee_types = [{name: "Monthly", id: 'monthly'}, {name: "Yearly", id: 'yearly'}, {name: "Onetime", id: 'onetime'}];
let notice_types = [{name: "Online", id: 'online'}, {name: "Offline", id: 'offline'}];
let types = [{name: "Free", id: 'free'}, {name: "Paid", id: 'paid'}];
const enabled = ref(false)
const form = useForm({
    'name': '',
    'body': '',
    'file': '',
    'status': true,
});
let editForm = useForm({
    '_method': 'PUT',
    'name': '',
    'body': '',
    'file': '',
    'status': true,
});


const file = ref(null);
let loading = ref(false);
const isOpen = ref(false)
const isOpenUpdateModal = ref(false)
const isDeleteModal = ref(false)
watch(enabled, (enabled) => {
    form.status = enabled
})

const filePreview = computed(() => {
    if (!file.value) {
        return;
    }
    form.file = file.value
    return file.value.name;
});

const editFilePreview = computed(() => {
    if (!file.value) {
        return;
    }
    editForm.file = file.value
    return file.value.name;
});

function closeModal() {
    isOpen.value = false
}

function closeUpdateModal() {
    isOpenUpdateModal.value = false
}

function closeDeleteModal() {
    isDeleteModal.value = false
}

function openModal() {
    isOpen.value = true
}

function openUpdateModal(notice) {
    isOpenUpdateModal.value = true;
    editForm.id = notice.id;
    editForm.name = notice.name;
    editForm.body = notice.body;
    editForm.status = notice.status;
}

function openDeleteModal(notice) {
    editForm = notice;
    isDeleteModal.value = true;

}

let submit = () => {
    loading.value = true;
    form.post(route('notices.store'), {
        preserveScroll: true,
        onSuccess: () => {
            isOpen.value = false;
            loading.value = false;
            file.value = null;
        },
        onError: () => {
            loading.value = false;
        }
    });
}

let updateNotice = () => {
    loading.value = true;
    editForm.post(route('notices.update', editForm.id), {
        preserveScroll: true,
        onSuccess: () => {
            isOpenUpdateModal.value = false;
            loading.value = false;
            file.value = null;
        },
        onError: () => {
            loading.value = false;
        }
    });
}

let deleteNotice = () => {
    loading.value = true;
    isDeleteModal.value = false;
    router.delete(route('notices.destroy', editForm.id), {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => {

            loading.value = false;
        },
        onError: () => {
            loading.value = false;
        }
    });

}

let search = ref(props.filters.search);

watch(search, debounce(function (value) {
        loading.value = true;
        router.get(route('notices.index', {search: value}), {}, {
            preserveState: true,
            replace: true,
            onSuccess: loading.value = false
        });
    }, 300),
);


</script>

<template>
    <Head :title="__('main.notice-list')"/>

    <AuthenticatedLayout>

        <div class="fixed flex items-center justify-center h-screen z-50 w-full bg-slate-100 opacity-25 inset-10"
             v-if="loading">

            <ion-icon name="sync" class="animate-spin text-6xl"></ion-icon>

        </div>

        <div class="py-10 max-w-8xl mx-auto">

            <div id="content" class="">

                <Header title="main.notice-list"></Header>

                <div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-5">

                    <div
                        class="flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900">

                        <label for="table-search" class="sr-only">Search</label>
                        <div class="relative">
                            <div
                                class="absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none">
                                <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                     xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                          stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                                </svg>
                            </div>
                            <input v-model="search" type="text" id="table-search-users"
                                   class="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                   placeholder="Search for Notice">
                        </div>

                        <div>

                            <button
                                type="button"
                                @click="openModal"
                                class="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                            >
                                Add Notice
                            </button>
                        </div>
                    </div>
                    <div v-if="notices">
                        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                            <thead
                                class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="p-4">
                                    <div class="flex items-center">
                                        ID
                                    </div>
                                </th>

                                <th scope="col" class="px-6 py-3">
                                    Name
                                </th>
                                <th scope="col" class="px-6 py-3">File Size</th>
                                <th scope="col" class="px-6 py-3">
                                    File Type
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Status
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Action
                                </th>
                            </tr>
                            </thead>
                            <tbody>

                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                                v-for="(notice,index) in notices.data" :key="index">
                                <td class="w-4 p-2">
                                    <div class="flex items-center">
                                        {{ index + 1 }}

                                    </div>
                                </td>
                                <th scope="row" class="p-2">
                                    <div class="flex items-center">
                                        {{ notice.name }}

                                    </div>
                                </th>


                                <td class="px-2 py-2 capitalize" v-text="notice.file_size">
                                </td>
                                <td class="px-2 py-2 capitalize" v-text="notice.file_type">
                                </td>
                                <td class="px-2 py-2">
                                    <span v-if="notice.status"
                                          class="bg-green-600 text-white py-1 px-2 rounded-md font-normal">Published</span>
                                    <span v-else class="bg-red-600 text-white py-1 px-2 rounded-md font-normal">Unpublished</span>
                                </td>
                                <td class="px-2 py-2 space-x-3">
                                    <a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline"
                                       v-on:click="openUpdateModal(notice)">
                                        <ion-icon name="create"
                                                  class="pt-2 " size="large"></ion-icon>
                                    </a>
                                    <a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline"
                                       v-on:click="openDeleteModal(notice)">
                                        <ion-icon class="pt-2 text-red-500" name="trash" size="large"></ion-icon>
                                    </a>
                                </td>
                            </tr>

                            </tbody>
                        </table>

                        <Pagination :meta="notices.meta"></Pagination>
                    </div>

                    <div v-else
                         class="text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal">
                        Data Not Found
                    </div>
                </div>

                <!--Start Add Modal-->
                <TransitionRoot appear :show="isOpen" as="template">
                    <Dialog as="div" @close="closeModal" class="relative z-10">
                        <TransitionChild
                            as="template"
                            enter="duration-500 ease-out"
                            enter-from="opacity-0"
                            enter-to="opacity-100"
                            leave="duration-500 ease-in"
                            leave-from="opacity-100"
                            leave-to="opacity-0"
                        >
                            <div class="fixed inset-0 bg-black/25"/>
                        </TransitionChild>

                        <div class="fixed inset-0 overflow-y-auto">
                            <div
                                class="flex min-h-full items-center justify-center p-4 text-center"
                            >
                                <TransitionChild
                                    as="template"
                                    enter="duration-300 ease-out"
                                    enter-from="opacity-0 scale-95"
                                    enter-to="opacity-100 scale-100"
                                    leave="duration-200 ease-in"
                                    leave-from="opacity-100 scale-100"
                                    leave-to="opacity-0 scale-95"
                                >
                                    <DialogPanel
                                        class="w-full max-w-3xl transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all"
                                    >

                                        <div class="flex justify-between justify-items-center items-center py-2">
                                            <DialogTitle
                                                as="h3"
                                                class="text-lg font-medium leading-6 text-gray-900"
                                            >
                                                Add New Notice
                                            </DialogTitle>
                                            <div>
                                                <button type="button"
                                                        class="text-5xl leading-6 text-gray-400 font-normal"
                                                        @click="closeModal" data-bs-dismiss="modal" aria-label="Close">
                                                    &times;
                                                </button>
                                            </div>

                                        </div>
                                        <hr>

                                        <div class="mt-2 flex space-x-6 justify-between w-full">
                                                {{form}}
                                           <span v-if="filePreview" class="w-6/12">{{filePreview}}</span>
                                            <span v-else class="w-6/12"></span>
                                            <input type="file" class="form-input px-4 py-3 rounded-md sr-only"
                                                   id="file"
                                                   v-on:change="file = $event.target.files[0]">
                                            <button
                                                class="text-lg font-semibold w-6/12 h-20 text-indigo-600 border-gray-200 border-2 flex items-center justify-center"
                                                v-if="file" v-on:click="file = null" type="button">Clear
                                            </button>

                                            <label for="file"
                                                   class="text-lg font-semibold w-6/12 h-20 text-indigo-600 border-gray-200 border-2 flex items-center justify-center"
                                                   v-else>Select New File</label>

                                        </div>
                                        <div class="text-lg text-red-600 font-semibold"
                                             v-if="form.errors.file">{{ form.errors.file }}
                                        </div>
                                        <div class="mt-2">
                                            <label for="name" class="text-lg font-semibold">Name</label>
                                            <input type="text" class="form-input px-3 rounded-md w-full my-2"
                                                   id="name" v-model="form.name"
                                                   placeholder="Enter Your Notice Name">
                                            <span class="text-lg text-red-600 font-semibold"
                                                  v-if="form.errors.name">{{ form.errors.name }}</span>
                                        </div>




                                        <div class="mt-2">
                                            <label for="des" class="text-lg font-semibold">Notice Description</label>

                                            <span class="text-lg text-red-600 font-semibold" v-if="form.errors.body">{{
                                                    form.errors.body
                                                }}</span>
                                            <QuillEditor theme="snow" v-model:content=form.body contentType="html"
                                                         toolbar="essential"
                                                         placeholder="Enter Your Notice Description"/>
                                        </div>
                                        <div class="mt-2 flex space-x-4 justify-items-center items-center">
                                            <label for="name" class="text-lg font-semibold">Publish Status</label>
                                            <input-switch
                                                v-model="form.status">

                                            </input-switch>

                                        </div>
                                        <div class="mt-4 float-end space-x-2">
                                            <button
                                                type="button"
                                                class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                                                @click="submit"
                                            >
                                                Submit
                                            </button>
                                            <button type="button"
                                                    class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                                                    @click="closeModal">Cancel
                                            </button>
                                        </div>
                                    </DialogPanel>
                                </TransitionChild>
                            </div>
                        </div>
                    </Dialog>
                </TransitionRoot>
                <!--End Add Modal-->
                <!--Start Update Modal-->
                <TransitionRoot appear :show="isOpenUpdateModal" as="template">
                    <Dialog as="div" @close="closeUpdateModal" class="relative z-10">
                        <TransitionChild
                            as="template"
                            enter="duration-500 ease-out"
                            enter-from="opacity-0"
                            enter-to="opacity-100"
                            leave="duration-500 ease-in"
                            leave-from="opacity-100"
                            leave-to="opacity-0"
                        >
                            <div class="fixed inset-0 bg-black/25"/>
                        </TransitionChild>

                        <div class="fixed inset-0 overflow-y-auto">
                            <div
                                class="flex min-h-full items-center justify-center p-4 text-center"
                            >
                                <TransitionChild
                                    as="template"
                                    enter="duration-300 ease-out"
                                    enter-from="opacity-0 scale-95"
                                    enter-to="opacity-100 scale-100"
                                    leave="duration-200 ease-in"
                                    leave-from="opacity-100 scale-100"
                                    leave-to="opacity-0 scale-95"
                                >
                                    <DialogPanel
                                        class="w-full max-w-3xl transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all"
                                    >

                                        <div class="flex justify-between justify-items-center items-center py-2">
                                            <DialogTitle
                                                as="h3"
                                                class="text-lg font-medium leading-6 text-gray-900"
                                            >
                                                Update Notice
                                            </DialogTitle>
                                            <div>
                                                <button type="button"
                                                        class="text-5xl leading-6 text-gray-400 font-normal"
                                                        @click="closeUpdateModal" data-bs-dismiss="modal"
                                                        aria-label="Close">&times;
                                                </button>
                                            </div>

                                        </div>
                                        <hr>

                                        <div class="mt-2 flex space-x-6 justify-between w-full">

                                            <span v-if="editFilePreview" class="w-6/12">{{editFilePreview}}</span>
                                            <span v-else class="w-6/12"></span>
                                            <input type="file" class="form-input px-4 py-3 rounded-md sr-only"
                                                   id="file"
                                                   v-on:change="file = $event.target.files[0]">
                                            <button
                                                class="text-lg font-semibold w-6/12 h-20 text-indigo-600 border-gray-200 border-2 flex items-center justify-center"
                                                v-if="file" v-on:click="file = null" type="button">Clear
                                            </button>

                                            <label for="file"
                                                   class="text-lg font-semibold w-6/12 h-20 text-indigo-600 border-gray-200 border-2 flex items-center justify-center"
                                                   v-else>Select New File</label>

                                        </div>
                                        <div class="text-lg text-red-600 font-semibold"
                                             v-if="editForm.errors.file">{{ editForm.errors.file }}
                                        </div>
                                        <div class="mt-2">
                                            <label for="name" class="text-lg font-semibold">Name</label>
                                            <input type="text" class="form-input px-3 rounded-md w-full my-2"
                                                   id="name" v-model="editForm.name"
                                                   placeholder="Enter Your Notice Name">
                                            <span class="text-lg text-red-600 font-semibold"
                                                  v-if="editForm.errors.name">{{ editForm.errors.name }}</span>
                                        </div>




                                        <div class="mt-2">
                                            <label for="des" class="text-lg font-semibold">Notice Description</label>

                                            <span class="text-lg text-red-600 font-semibold" v-if="editForm.errors.body">{{
                                                    editForm.errors.body
                                                }}</span>
                                            <QuillEditor theme="snow" v-model:content=editForm.body contentType="html"
                                                         toolbar="essential"
                                                         placeholder="Enter Your Notice Description"/>
                                        </div>
                                        <div class="mt-2 flex space-x-4 justify-items-center items-center">
                                            <label for="name" class="text-lg font-semibold">Publish Status</label>
                                            <input-switch
                                                v-model="editForm.status">

                                            </input-switch>

                                        </div>
                                        <div class="mt-4 float-end space-x-2">
                                            <button
                                                type="button"
                                                class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                                                @click="updateNotice"
                                            >
                                                Update
                                            </button>
                                            <button type="button"
                                                    class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                                                    @click="closeUpdateModal">Cancel
                                            </button>
                                        </div>
                                    </DialogPanel>
                                </TransitionChild>
                            </div>
                        </div>
                    </Dialog>
                </TransitionRoot>
                <!--End Update Modal-->
                <!--Start Deelete Modal-->
                <TransitionRoot appear :show="isDeleteModal" as="template">
                    <Dialog as="div" @close="closeDeleteModal" class="relative z-10">
                        <TransitionChild
                            as="template"
                            enter="duration-500 ease-out"
                            enter-from="opacity-0"
                            enter-to="opacity-100"
                            leave="duration-500 ease-in"
                            leave-from="opacity-100"
                            leave-to="opacity-0"
                        >
                            <div class="fixed inset-0 bg-black/25"/>
                        </TransitionChild>

                        <div class="fixed inset-0 overflow-y-auto">
                            <div
                                class="flex min-h-full items-center justify-center p-4 text-center"
                            >
                                <TransitionChild
                                    as="template"
                                    enter="duration-300 ease-out"
                                    enter-from="opacity-0 scale-95"
                                    enter-to="opacity-100 scale-100"
                                    leave="duration-200 ease-in"
                                    leave-from="opacity-100 scale-100"
                                    leave-to="opacity-0 scale-95"
                                >
                                    <DialogPanel
                                        class="w-full max-w-xl transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all"
                                    >

                                        <div class="flex justify-between justify-items-center items-center py-2">
                                            <DialogTitle
                                                as="h3"
                                                class="text-lg font-medium leading-6 text-gray-900"
                                            >
                                                Delete Notice
                                            </DialogTitle>
                                            <div>
                                                <button type="button"
                                                        class="text-5xl leading-6 text-gray-400 font-normal"
                                                        @click="closeDeleteModal" data-bs-dismiss="modal"
                                                        aria-label="Close">&times;
                                                </button>
                                            </div>

                                        </div>
                                        <hr>

                                        <div class="mt-2">
                                            <strong>You Are Sure ? You Want to Delete This Notice
                                                ({{ editForm.name }})</strong>
                                        </div>

                                        <div class="mt-5 text-center space-x-2">
                                            <button
                                                type="button"
                                                class="inline-flex justify-center rounded-md border border-transparent bg-green-600 px-4 py-2 text-sm font-semibold text-gray-50 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                                                @click="deleteNotice"
                                            >
                                                Yes
                                            </button>
                                            <button type="button"
                                                    class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                                                    @click="closeDeleteModal">Cancel
                                            </button>
                                        </div>
                                    </DialogPanel>
                                </TransitionChild>
                            </div>
                        </div>
                    </Dialog>
                </TransitionRoot>
                <!--End Deelete Modal-->

            </div>
        </div>
    </AuthenticatedLayout>
</template>

